const { Pool } = require('pg')

const pool = new Pool({
  host:     process.env.DB_HOST,
  port:     process.env.DB_PORT,
  database: process.env.DB_NAME,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
})

const initDatabase = async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id         SERIAL PRIMARY KEY,
        nombre     VARCHAR(100)  NOT NULL,
        email      VARCHAR(255)  UNIQUE NOT NULL,
        password   VARCHAR(255)  NOT NULL,
        rol        VARCHAR(20)   DEFAULT 'usuario' CHECK (rol IN ('admin','usuario')),
        created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
      )
    `)

    await pool.query(`
      CREATE TABLE IF NOT EXISTS wallets (
        id               SERIAL PRIMARY KEY,
        usuario_id       INTEGER UNIQUE NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
        saldo            NUMERIC(15,2)  NOT NULL DEFAULT 0 CHECK (saldo >= 0),
        saldo_bloqueado  NUMERIC(15,2)  NOT NULL DEFAULT 0,
        estado           VARCHAR(20)    NOT NULL DEFAULT 'activa' CHECK (estado IN ('activa','suspendida','bloqueada')),
        created_at       TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
        updated_at       TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
      )
    `)

    await pool.query(`
      CREATE TABLE IF NOT EXISTS transacciones (
        id           SERIAL PRIMARY KEY,
        wallet_id    INTEGER       NOT NULL REFERENCES wallets(id),
        tipo         VARCHAR(20)   NOT NULL CHECK (tipo IN ('recarga','retiro','transferencia_enviada','transferencia_recibida')),
        monto        NUMERIC(15,2) NOT NULL CHECK (monto > 0),
        descripcion  TEXT,
        categoria    VARCHAR(50)   DEFAULT 'general',
        estado       VARCHAR(20)   NOT NULL DEFAULT 'completada' CHECK (estado IN ('pendiente','completada','fallida')),
        created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
      )
    `)

    await pool.query(`
      CREATE TABLE IF NOT EXISTS transferencias (
        id                    SERIAL PRIMARY KEY,
        wallet_origen_id      INTEGER       NOT NULL REFERENCES wallets(id),
        wallet_destino_id     INTEGER       NOT NULL REFERENCES wallets(id),
        nombre_destinatario   VARCHAR(100),
        email_destinatario    VARCHAR(255),
        nombre_remitente      VARCHAR(100),
        email_remitente       VARCHAR(255),
        monto                 NUMERIC(15,2) NOT NULL CHECK (monto > 0),
        descripcion           TEXT,
        estado                VARCHAR(20)   NOT NULL DEFAULT 'completada',
        created_at            TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Tabla de destinatarios recientes por usuario
    await pool.query(`
      CREATE TABLE IF NOT EXISTS destinatarios_recientes (
        id           SERIAL PRIMARY KEY,
        usuario_id   INTEGER       NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
        nombre       VARCHAR(100),
        email        VARCHAR(255)  NOT NULL,
        avatar       VARCHAR(10),
        ultima_vez   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
        UNIQUE (usuario_id, email)
      )
    `)

    // Tabla de notificaciones
    await pool.query(`
      CREATE TABLE IF NOT EXISTS notificaciones (
        id           SERIAL PRIMARY KEY,
        usuario_id   INTEGER       NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
        tipo         VARCHAR(50)   NOT NULL DEFAULT 'transferencia_recibida',
        mensaje      TEXT          NOT NULL,
        monto        NUMERIC(15,2),
        de_usuario   VARCHAR(100),
        leida        BOOLEAN       DEFAULT false,
        created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
      )
    `)

    console.log("✅ Base de datos inicializada correctamente")

  } catch (error) {
    console.error("❌ Error inicializando la BD:", error)
  }
}

module.exports = { pool, initDatabase }
