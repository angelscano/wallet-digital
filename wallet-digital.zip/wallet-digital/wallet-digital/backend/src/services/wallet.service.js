const WalletModel = require('../models/wallet.model')
const { AppError } = require('../middlewares/errorHandler')

class WalletService {
  static async obtenerSaldo(usuarioId) {
    const wallet = await WalletModel.buscarPorUsuarioId(usuarioId)
    if (!wallet) throw new AppError('Wallet no encontrada', 404)
    return wallet
  }

  static async recargar(usuarioId, monto, descripcion) {
    if (!monto || monto <= 0) throw new AppError('El monto debe ser mayor a cero', 400)
    if (monto > 50000000)     throw new AppError('Monto supera el límite permitido', 400)
    return WalletModel.recargar(usuarioId, monto, descripcion)
  }

  static async retirar(usuarioId, monto, descripcion) {
    if (!monto || monto <= 0) throw new AppError('El monto debe ser mayor a cero', 400)
    try {
      return await WalletModel.retirar(usuarioId, monto, descripcion)
    } catch (err) {
      if (err.message === 'Saldo insuficiente') throw new AppError('Saldo insuficiente', 422)
      throw err
    }
  }

  static async transferir(usuarioOrigenId, emailDestino, monto, descripcion) {
    if (!monto || monto <= 0)     throw new AppError('El monto debe ser mayor a cero', 400)
    if (!emailDestino)            throw new AppError('El correo destino es requerido', 400)
    try {
      return await WalletModel.transferir(usuarioOrigenId, emailDestino, monto, descripcion)
    } catch (err) {
      if (err.message === 'Saldo insuficiente')              throw new AppError('Saldo insuficiente', 422)
      if (err.message === 'Usuario destino no encontrado')   throw new AppError('Usuario destino no encontrado', 404)
      if (err.message === 'No puedes transferirte a ti mismo') throw new AppError('No puedes transferirte a ti mismo', 400)
      throw err
    }
  }

  static async historial(usuarioId, opciones) {
    return WalletModel.historial(usuarioId, opciones)
  }
}

module.exports = WalletService
