const { pool } = require('../config/database')

class WalletModel {
  static async crearParaUsuario(usuarioId) {
    const { rows } = await pool.query(
      `INSERT INTO wallets (usuario_id) VALUES ($1) RETURNING *`,
      [usuarioId]
    )
    return rows[0]
  }

  static async buscarPorUsuarioId(usuarioId) {
    const { rows } = await pool.query(
      `SELECT * FROM wallets WHERE usuario_id = $1`,
      [usuarioId]
    )
    return rows[0] || null
  }

  static async obtenerSaldo(usuarioId) {
    const { rows } = await pool.query(
      `SELECT saldo FROM wallets WHERE usuario_id = $1`,
      [usuarioId]
    )
    return rows[0]?.saldo ?? null
  }

  // Recarga: suma saldo y registra transacción (en una transacción SQL)
  static async recargar(usuarioId, monto, descripcion = 'Recarga de saldo') {
    const client = await pool.connect()
    try {
      await client.query('BEGIN')
      const { rows: [wallet] } = await client.query(
        `UPDATE wallets SET saldo = saldo + $1, updated_at = NOW()
         WHERE usuario_id = $2 RETURNING *`,
        [monto, usuarioId]
      )
      const { rows: [tx] } = await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'recarga', $2, $3, 'recarga') RETURNING *`,
        [wallet.id, monto, descripcion]
      )
      await client.query('COMMIT')
      return { wallet, transaccion: tx }
    } catch (err) {
      await client.query('ROLLBACK')
      throw err
    } finally {
      client.release()
    }
  }

  // Retiro: resta saldo (con validación) y registra transacción
  static async retirar(usuarioId, monto, descripcion = 'Retiro de saldo') {
    const client = await pool.connect()
    try {
      await client.query('BEGIN')
      const { rows: [wallet] } = await client.query(
        `UPDATE wallets SET saldo = saldo - $1, updated_at = NOW()
         WHERE usuario_id = $2 AND saldo >= $1 RETURNING *`,
        [monto, usuarioId]
      )
      if (!wallet) throw new Error('Saldo insuficiente')
      const { rows: [tx] } = await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'retiro', $2, $3, 'retiro') RETURNING *`,
        [wallet.id, monto, descripcion]
      )
      await client.query('COMMIT')
      return { wallet, transaccion: tx }
    } catch (err) {
      await client.query('ROLLBACK')
      throw err
    } finally {
      client.release()
    }
  }

  // Transferencia atómica entre dos wallets
  static async transferir(usuarioOrigenId, emailDestino, monto, descripcion = '') {
    const client = await pool.connect()
    try {
      await client.query('BEGIN')

      // Buscar destino
      const { rows: [usuarioDest] } = await client.query(
        `SELECT u.id, u.nombre, w.id AS wallet_id
         FROM usuarios u JOIN wallets w ON w.usuario_id = u.id
         WHERE u.email = $1`,
        [emailDestino]
      )
      if (!usuarioDest) throw new Error('Usuario destino no encontrado')
      if (usuarioDest.id === usuarioOrigenId) throw new Error('No puedes transferirte a ti mismo')

      // Descontar del origen
      const { rows: [walletOrigen] } = await client.query(
        `UPDATE wallets SET saldo = saldo - $1, updated_at = NOW()
         WHERE usuario_id = $2 AND saldo >= $1 RETURNING *`,
        [monto, usuarioOrigenId]
      )
      if (!walletOrigen) throw new Error('Saldo insuficiente')

      // Abonar al destino
      await client.query(
        `UPDATE wallets SET saldo = saldo + $1, updated_at = NOW() WHERE id = $2`,
        [monto, usuarioDest.wallet_id]
      )

      // Registrar transferencia
      const { rows: [transf] } = await client.query(
        `INSERT INTO transferencias (wallet_origen_id, wallet_destino_id, monto, descripcion)
         VALUES ($1, $2, $3, $4) RETURNING *`,
        [walletOrigen.id, usuarioDest.wallet_id, monto, descripcion]
      )

      // Transacciones para historial
      const desc = descripcion ? `Transferencia a ${usuarioDest.nombre} — ${descripcion}` : `Transferencia enviada a ${usuarioDest.nombre}`
      await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'transferencia_enviada', $2, $3, 'transferencia')`,
        [walletOrigen.id, monto, desc]
      )
      await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'transferencia_recibida', $2, $3, 'transferencia')`,
        [usuarioDest.wallet_id, monto, `Transferencia recibida`]
      )

      await client.query('COMMIT')
      return { walletOrigen, transferencia: transf }
    } catch (err) {
      await client.query('ROLLBACK')
      throw err
    } finally {
      client.release()
    }
  }

  // Historial paginado
  static async historial(usuarioId, { page = 1, limit = 20, tipo } = {}) {
    const offset = (page - 1) * limit
    const params = [usuarioId, limit, offset]
    let filtro = ''
    if (tipo) { filtro = `AND t.tipo = $4`; params.push(tipo) }

    const { rows } = await pool.query(
      `SELECT t.* FROM transacciones t
       JOIN wallets w ON w.id = t.wallet_id
       WHERE w.usuario_id = $1 ${filtro}
       ORDER BY t.created_at DESC
       LIMIT $2 OFFSET $3`,
      params
    )
    const { rows: [{ total }] } = await pool.query(
      `SELECT COUNT(*) AS total FROM transacciones t
       JOIN wallets w ON w.id = t.wallet_id
       WHERE w.usuario_id = $1 ${tipo ? `AND t.tipo = $2` : ''}`,
      tipo ? [usuarioId, tipo] : [usuarioId]
    )
    return { transacciones: rows, total: parseInt(total), page, limit }
  }
}

module.exports = WalletModel
