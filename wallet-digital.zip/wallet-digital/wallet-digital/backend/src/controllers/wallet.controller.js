const WalletService = require('../services/wallet.service')

class WalletController {
  // GET /api/wallet
  static async obtenerWallet(req, res, next) {
    try {
      const wallet = await WalletService.obtenerSaldo(req.usuario.id)
      res.json({ success: true, data: { wallet } })
    } catch (err) { next(err) }
  }

  // POST /api/wallet/recargar
  static async recargar(req, res, next) {
    try {
      const { monto, descripcion } = req.body
      const result = await WalletService.recargar(req.usuario.id, Number(monto), descripcion)
      res.json({ success: true, message: 'Recarga exitosa', data: result })
    } catch (err) { next(err) }
  }

  // POST /api/wallet/retirar
  static async retirar(req, res, next) {
    try {
      const { monto, descripcion } = req.body
      const result = await WalletService.retirar(req.usuario.id, Number(monto), descripcion)
      res.json({ success: true, message: 'Retiro exitoso', data: result })
    } catch (err) { next(err) }
  }

  // POST /api/wallet/transferir
  static async transferir(req, res, next) {
    try {
      const { emailDestino, monto, descripcion } = req.body
      const result = await WalletService.transferir(req.usuario.id, emailDestino, Number(monto), descripcion)
      res.json({ success: true, message: 'Transferencia exitosa', data: result })
    } catch (err) { next(err) }
  }

  // GET /api/wallet/historial
  static async historial(req, res, next) {
    try {
      const { page = 1, limit = 20, tipo } = req.query
      const result = await WalletService.historial(req.usuario.id, { page: Number(page), limit: Number(limit), tipo })
      res.json({ success: true, data: result })
    } catch (err) { next(err) }
  }
}

module.exports = WalletController
