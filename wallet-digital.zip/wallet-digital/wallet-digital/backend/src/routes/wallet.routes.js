const express    = require('express')
const WalletController = require('../controllers/wallet.controller')
const { verificarAuth } = require('../middlewares/auth.middleware')

const router = express.Router()

// Todas las rutas de wallet requieren autenticación
router.use(verificarAuth)

router.get('/',            WalletController.obtenerWallet)
router.post('/recargar',   WalletController.recargar)
router.post('/retirar',    WalletController.retirar)
router.post('/transferir', WalletController.transferir)
router.get('/historial',   WalletController.historial)

module.exports = router
