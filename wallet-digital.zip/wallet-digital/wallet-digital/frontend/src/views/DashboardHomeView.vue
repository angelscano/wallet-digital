<script setup>
import { ref, computed } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useWalletStore } from '@/stores/wallet'

const authStore = useAuthStore()
const walletStore = useWalletStore()

// Mock data para transacciones recientes
const recentTransactions = ref([
  { id: 1, type: 'income', description: 'Transferencia recibida', amount: 500.00, date: '2024-01-15', icon: 'arrow-down' },
  { id: 2, type: 'expense', description: 'Pago de servicios', amount: 120.00, date: '2024-01-14', icon: 'arrow-up' },
  { id: 3, type: 'income', description: 'Recarga de saldo', amount: 1000.00, date: '2024-01-13', icon: 'arrow-down' },
  { id: 4, type: 'expense', description: 'Compra en línea', amount: 89.99, date: '2024-01-12', icon: 'arrow-up' }
])

const formatCurrency = (value) => {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP'
  }).format(value)
}

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('es-CO', {
    day: 'numeric',
    month: 'short'
  })
}
</script>

<template>
  <div class="home-content">
    <!-- Welcome Section -->
    <div class="welcome-section">
      <div class="welcome-text">
        <h1>Hola, {{ authStore.nombreUsuario }}</h1>
        <p>Bienvenido a tu billetera digital</p>
      </div>
      <div class="welcome-date">
        {{ new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long' }) }}
      </div>
    </div>

    <!-- Balance Card -->
    <div class="balance-card">
      <div class="balance-header">
        <span class="balance-label">Saldo disponible</span>
        <svg class="balance-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
        </svg>
      </div>
      <div class="balance-amount">{{ formatCurrency(walletStore.balance) }}</div>
      <div class="balance-actions">
        <router-link to="/dashboard/balance" class="action-btn primary">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="1" x2="12" y2="23"></line>
            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
          </svg>
          Gestionar
        </router-link>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
      <router-link to="/dashboard/transferir" class="quick-action">
        <div class="action-icon send">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <polyline points="19 12 12 19 5 12"></polyline>
          </svg>
        </div>
        <span>Enviar</span>
      </router-link>

      <router-link to="/dashboard/balance" class="quick-action">
        <div class="action-icon receive">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="19" x2="12" y2="5"></line>
            <polyline points="5 12 12 5 19 12"></polyline>
          </svg>
        </div>
        <span>Recargar</span>
      </router-link>

      <router-link to="/dashboard/historial" class="quick-action">
        <div class="action-icon history">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
          </svg>
        </div>
        <span>Historial</span>
      </router-link>
    </div>

    <!-- Recent Transactions -->
    <div class="recent-transactions">
      <div class="section-header">
        <h2>Transacciones recientes</h2>
        <router-link to="/dashboard/historial" class="see-all">Ver todo</router-link>
      </div>

      <div class="transactions-list">
        <div v-for="tx in recentTransactions" :key="tx.id" class="transaction-item">
          <div class="transaction-icon" :class="tx.type">
            <svg v-if="tx.type === 'income'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
              <polyline points="17 6 23 6 23 12"></polyline>
            </svg>
            <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline>
              <polyline points="17 18 23 18 23 12"></polyline>
            </svg>
          </div>
          <div class="transaction-info">
            <span class="transaction-desc">{{ tx.description }}</span>
            <span class="transaction-date">{{ formatDate(tx.date) }}</span>
          </div>
          <div class="transaction-amount" :class="tx.type">
            {{ tx.type === 'income' ? '+' : '-' }}{{ formatCurrency(tx.amount) }}
          </div>
        </div>
      </div>
    </div>

    <!-- Next Steps -->
    <div class="next-steps-card">
      <h3>Próximos pasos</h3>
      <p>El módulo de autenticación está completo. Continúa desarrollando:</p>
      <ul>
        <li><span class="arrow">→</span> Gestión de saldo (recargas y retiros)</li>
        <li><span class="arrow">→</span> Transferencias entre usuarios</li>
        <li><span class="arrow">→</span> Historial de transacciones</li>
        <li><span class="arrow">→</span> Límites de gasto</li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.home-content {
  max-width: 900px;
}

.welcome-section {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.welcome-text h1 {
  font-size: 1.75rem;
  font-weight: 700;
  color: #1e3a5f;
  margin-bottom: 0.25rem;
}

.welcome-text p {
  color: #64748b;
  font-size: 0.95rem;
}

.welcome-date {
  color: #64748b;
  font-size: 0.875rem;
  text-align: right;
  text-transform: capitalize;
}

.balance-card {
  background: linear-gradient(135deg, #1e3a5f 0%, #0f2744 100%);
  border-radius: 16px;
  padding: 1.5rem;
  color: white;
  margin-bottom: 1.5rem;
}

.balance-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.balance-label {
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.7);
}

.balance-icon {
  width: 20px;
  height: 20px;
  color: rgba(255, 255, 255, 0.5);
}

.balance-amount {
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 1rem;
}

.balance-actions {
  display: flex;
  gap: 0.75rem;
}

.action-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.625rem 1.25rem;
  border-radius: 10px;
  font-size: 0.875rem;
  font-weight: 600;
  text-decoration: none;
  transition: all 0.2s;
}

.action-btn.primary {
  background: #3b82f6;
  color: white;
}

.action-btn.primary:hover {
  background: #2563eb;
}

.action-btn svg {
  width: 18px;
  height: 18px;
}

.quick-actions {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.quick-action {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.75rem;
  padding: 1.25rem;
  background: white;
  border-radius: 12px;
  text-decoration: none;
  color: #1e3a5f;
  font-weight: 500;
  font-size: 0.875rem;
  transition: all 0.2s;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.quick-action:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.action-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.action-icon.send {
  background: rgba(59, 130, 246, 0.1);
  color: #3b82f6;
}

.action-icon.receive {
  background: rgba(16, 185, 129, 0.1);
  color: #10b981;
}

.action-icon.history {
  background: rgba(139, 92, 246, 0.1);
  color: #8b5cf6;
}

.action-icon svg {
  width: 24px;
  height: 24px;
}

.recent-transactions {
  background: white;
  border-radius: 12px;
  padding: 1.25rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}

.section-header h2 {
  font-size: 1rem;
  font-weight: 600;
  color: #1e3a5f;
}

.see-all {
  font-size: 0.875rem;
  color: #3b82f6;
  text-decoration: none;
  font-weight: 500;
}

.see-all:hover {
  text-decoration: underline;
}

.transactions-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.transaction-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  background: #f8fafc;
  border-radius: 10px;
}

.transaction-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.transaction-icon.income {
  background: rgba(16, 185, 129, 0.1);
  color: #10b981;
}

.transaction-icon.expense {
  background: rgba(239, 68, 68, 0.1);
  color: #ef4444;
}

.transaction-icon svg {
  width: 20px;
  height: 20px;
}

.transaction-info {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.transaction-desc {
  font-weight: 500;
  color: #1e3a5f;
  font-size: 0.875rem;
}

.transaction-date {
  font-size: 0.75rem;
  color: #64748b;
}

.transaction-amount {
  font-weight: 600;
  font-size: 0.875rem;
}

.transaction-amount.income {
  color: #10b981;
}

.transaction-amount.expense {
  color: #ef4444;
}

.next-steps-card {
  background: white;
  border-radius: 12px;
  padding: 1.25rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.next-steps-card h3 {
  font-size: 1rem;
  font-weight: 600;
  color: #1e3a5f;
  margin-bottom: 0.5rem;
}

.next-steps-card p {
  color: #64748b;
  font-size: 0.875rem;
  margin-bottom: 1rem;
}

.next-steps-card ul {
  list-style: none;
}

.next-steps-card li {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.5rem 0;
  color: #64748b;
  font-size: 0.875rem;
}

.arrow {
  color: #3b82f6;
  font-weight: 700;
}
</style>
