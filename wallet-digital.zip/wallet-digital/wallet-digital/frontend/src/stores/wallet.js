import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useWalletStore = defineStore('wallet', () => {
  const balance = ref(1250000)
  const transactions = ref([
    { id: 1, type: 'income',   description: 'Recarga inicial',            amount: 500000, date: '2024-01-15', time: '14:30', status: 'completed', category: 'recarga' },
    { id: 2, type: 'expense',  description: 'Transferencia enviada a Ana', amount: 50000,  date: '2024-01-14', time: '11:30', status: 'completed', category: 'transferencia' },
    { id: 3, type: 'income',   description: 'Transferencia recibida',      amount: 100000, date: '2024-01-13', time: '09:00', status: 'completed', category: 'transferencia' }
  ])

  // ── Getters ──────────────────────────────────────────────
  const totalIngresos = computed(() =>
    transactions.value.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
  )
  const totalGastos = computed(() =>
    transactions.value.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0)
  )
  const recentActivity = computed(() =>
    [...transactions.value].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5)
  )

  // ── Helper ───────────────────────────────────────────────
  function _now() {
    const d = new Date()
    return {
      date: d.toISOString().split('T')[0],
      time: d.toTimeString().slice(0, 5)
    }
  }

  // ── Acciones ─────────────────────────────────────────────
  function depositar(monto) {
    const n = Number(monto)
    if (!n || n <= 0) return false
    balance.value += n
    const { date, time } = _now()
    transactions.value.unshift({ id: Date.now(), type: 'income', description: 'Recarga de saldo', amount: n, date, time, status: 'completed', category: 'recarga' })
    return true
  }

  function retirar(monto) {
    const n = Number(monto)
    if (!n || n <= 0) return false
    if (n > balance.value) return false
    balance.value -= n
    const { date, time } = _now()
    transactions.value.unshift({ id: Date.now(), type: 'expense', description: 'Retiro de saldo', amount: n, date, time, status: 'completed', category: 'retiro' })
    return true
  }

  function transferir(monto, destinatario, descripcion) {
    const n = Number(monto)
    if (!n || n <= 0) return false
    if (n > balance.value) return false
    balance.value -= n
    const { date, time } = _now()
    const desc = descripcion
      ? `Transferencia a ${destinatario.name} — ${descripcion}`
      : `Transferencia enviada a ${destinatario.name}`
    transactions.value.unshift({ id: Date.now(), type: 'expense', description: desc, amount: n, date, time, status: 'completed', category: 'transferencia' })
    return true
  }

  return { balance, transactions, totalIngresos, totalGastos, recentActivity, depositar, retirar, transferir }
})
