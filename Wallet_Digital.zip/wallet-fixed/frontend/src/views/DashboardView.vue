<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useWalletStore } from '@/stores/wallet'

const authStore   = useAuthStore()
const walletStore = useWalletStore()
const sidebarOpen = ref(true)
const showNotifications = ref(false)

const unread = computed(() => walletStore.unreadNotifications)

function toggleSidebar() { sidebarOpen.value = !sidebarOpen.value }
function handleLogout()  { authStore.logout() }

function toggleNotifications() {
  showNotifications.value = !showNotifications.value
  if (showNotifications.value) walletStore.marcarNotificacionesLeidas()
}

function formatCurrency(v) {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(v)
}

function formatNotifTime(n) {
  if (!n.created_at) return `${n.date ?? ''} ${n.time ?? ''}`
  const d = new Date(n.created_at)
  return d.toLocaleDateString('es-CO', { day: 'numeric', month: 'short' }) + ' · ' + d.toTimeString().slice(0, 5)
}

onMounted(async () => {
  await walletStore.cargarDatos()
  walletStore.iniciarPolling()
})

onUnmounted(() => {
  walletStore.detenerPolling()
})
</script>

<template>
  <div class="wallet-layout">
    <aside class="sidebar" :class="{ 'sidebar-collapsed': !sidebarOpen }">
      <div class="sidebar-header">
        <div class="logo">
          <svg class="logo-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/>
            <path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>
          </svg>
          <span v-if="sidebarOpen" class="logo-text">Wallet</span>
        </div>
        <button @click="toggleSidebar" class="toggle-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path v-if="sidebarOpen" d="M11 19l-7-7 7-7M18 19l-7-7 7-7"/>
            <path v-else d="M13 6l6 6-6 6M5 6l6 6-6 6"/>
          </svg>
        </button>
      </div>

      <nav class="sidebar-nav">
        <router-link to="/dashboard" exact-active-class="active" class="nav-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
          <span v-if="sidebarOpen">Inicio</span>
        </router-link>
        <router-link to="/dashboard/transferir" active-class="active" class="nav-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/><polyline points="19 12 12 5 5 12"/></svg>
          <span v-if="sidebarOpen">Transferir</span>
        </router-link>
        <router-link to="/dashboard/historial" active-class="active" class="nav-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          <span v-if="sidebarOpen">Historial</span>
        </router-link>
      </nav>

      <div class="sidebar-footer">
        <div class="user-card" v-if="sidebarOpen">
          <div class="user-avatar">{{ authStore.nombreUsuario?.charAt(0).toUpperCase() || 'U' }}</div>
          <div class="user-info">
            <span class="user-name">{{ authStore.nombreUsuario }}</span>
            <span class="user-email">{{ authStore.usuario?.email }}</span>
          </div>
        </div>
        <button @click="handleLogout" class="logout-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          <span v-if="sidebarOpen">Cerrar Sesión</span>
        </button>
      </div>
    </aside>

    <main class="main-content">
      <!-- Topbar con notificaciones -->
      <div class="topbar">
        <div class="topbar-spacer"></div>
        <div class="topbar-right">
          <div class="notif-wrapper">
            <button class="notif-btn" @click="toggleNotifications" :class="{ active: showNotifications }">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
              </svg>
              <span v-if="unread > 0" class="notif-badge">{{ unread > 9 ? '9+' : unread }}</span>
            </button>

            <div v-if="showNotifications" class="notif-dropdown">
              <div class="notif-header">
                <span>Notificaciones</span>
                <span v-if="walletStore.notifications.length > 0" class="notif-count">{{ walletStore.notifications.length }}</span>
              </div>
              <div v-if="walletStore.notifications.length === 0" class="notif-empty">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                <p>Sin notificaciones</p>
              </div>
              <div v-else class="notif-list">
                <div v-for="n in walletStore.notifications" :key="n.id" class="notif-item" :class="{ unread: !n.leida && !n.read }">
                  <div class="notif-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                  </div>
                  <div class="notif-body">
                    <p class="notif-msg">{{ n.mensaje || n.message }}</p>
                    <span class="notif-amount">+ {{ formatCurrency(n.monto || n.amount) }}</span>
                    <span class="notif-time">{{ formatNotifTime(n) }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div v-if="showNotifications" class="notif-overlay" @click="showNotifications = false"></div>

      <div v-if="walletStore.loading && !walletStore.initialized" class="loading-screen">
        <div class="loading-spinner"></div>
        <p>Cargando tu billetera...</p>
      </div>
      <router-view v-else />
    </main>
  </div>
</template>

<style scoped>
.wallet-layout { display:flex;min-height:100vh;background-color:#f5f5f5; }
.sidebar { width:260px;background:linear-gradient(180deg,#1e3a5f 0%,#0f2744 100%);color:white;display:flex;flex-direction:column;transition:width .3s ease;position:fixed;height:100vh;z-index:100; }
.sidebar-collapsed { width:70px; }
.sidebar-header { padding:1.5rem;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,.1); }
.logo { display:flex;align-items:center;gap:.75rem; }
.logo-icon { width:32px;height:32px;color:#3b82f6;flex-shrink:0; }
.logo-text { font-size:1.5rem;font-weight:700;color:white; }
.toggle-btn { background:transparent;border:none;color:white;cursor:pointer;padding:.5rem;border-radius:8px;transition:background .2s; }
.toggle-btn:hover { background:rgba(255,255,255,.1); }
.toggle-btn svg { width:20px;height:20px; }
.sidebar-nav { flex:1;padding:1rem 0;overflow-y:auto; }
.nav-item { display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.7);text-decoration:none;transition:all .2s;font-size:.95rem;font-weight:500; }
.nav-item:hover { background:rgba(255,255,255,.1);color:white; }
.nav-item.active { background:rgba(59,130,246,.2);color:#3b82f6;border-left:3px solid #3b82f6; }
.nav-item svg { width:22px;height:22px;flex-shrink:0; }
.sidebar-collapsed .nav-item { justify-content:center;padding:.875rem; }
.sidebar-footer { padding:1rem;border-top:1px solid rgba(255,255,255,.1); }
.user-card { display:flex;align-items:center;gap:.75rem;padding:.75rem;background:rgba(255,255,255,.05);border-radius:10px;margin-bottom:1rem; }
.user-avatar { width:40px;height:40px;background:linear-gradient(135deg,#3b82f6 0%,#1d4ed8 100%);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1rem; }
.user-info { display:flex;flex-direction:column; }
.user-name { font-weight:600;font-size:.875rem; }
.user-email { font-size:.75rem;color:rgba(255,255,255,.6);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:140px; }
.logout-btn { width:100%;display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.75rem;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;border-radius:10px;cursor:pointer;transition:all .2s;font-size:.875rem;font-weight:500; }
.logout-btn:hover { background:rgba(239,68,68,.2); }
.logout-btn svg { width:18px;height:18px; }
.sidebar-collapsed .logout-btn { padding:.75rem; }
.sidebar-collapsed .user-card { display:none; }
.main-content { flex:1;margin-left:260px;padding:0;transition:margin-left .3s ease;display:flex;flex-direction:column; }
.sidebar-collapsed + .main-content { margin-left:70px; }
.topbar { display:flex;align-items:center;justify-content:space-between;padding:1rem 2rem 0;position:relative;z-index:200; }
.topbar-spacer { flex:1; }
.topbar-right { display:flex;align-items:center;gap:1rem; }
.notif-wrapper { position:relative; }
.notif-btn { position:relative;background:white;border:1px solid #e5e7eb;border-radius:12px;width:44px;height:44px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;color:#64748b;box-shadow:0 1px 3px rgba(0,0,0,.08); }
.notif-btn:hover,.notif-btn.active { background:#f1f5f9;border-color:#3b82f6;color:#3b82f6; }
.notif-btn svg { width:20px;height:20px; }
.notif-badge { position:absolute;top:-6px;right:-6px;background:#ef4444;color:white;font-size:.65rem;font-weight:700;min-width:18px;height:18px;border-radius:9px;display:flex;align-items:center;justify-content:center;padding:0 4px;border:2px solid white;animation:pulse 1.5s ease-in-out infinite; }
@keyframes pulse { 0%,100% { transform:scale(1); } 50% { transform:scale(1.15); } }
.notif-dropdown { position:absolute;top:calc(100% + 8px);right:0;width:320px;background:white;border-radius:16px;box-shadow:0 8px 32px rgba(0,0,0,.15);border:1px solid #e5e7eb;overflow:hidden;z-index:300; }
.notif-header { display:flex;align-items:center;justify-content:space-between;padding:1rem 1.25rem;font-weight:600;color:#1e3a5f;border-bottom:1px solid #f1f5f9;font-size:.9rem; }
.notif-count { background:#3b82f6;color:white;font-size:.7rem;padding:2px 7px;border-radius:10px; }
.notif-empty { display:flex;flex-direction:column;align-items:center;gap:.5rem;padding:2rem;color:#94a3b8;font-size:.85rem; }
.notif-empty svg { width:32px;height:32px; }
.notif-list { max-height:320px;overflow-y:auto; }
.notif-item { position:relative;display:flex;align-items:flex-start;gap:.75rem;padding:1rem 1.25rem;border-bottom:1px solid #f8fafc;transition:background .15s; }
.notif-item:hover { background:#f8fafc; }
.notif-item.unread { background:rgba(59,130,246,.04); }
.notif-item.unread::before { content:'';position:absolute;left:0;top:0;bottom:0;width:4px;background:#3b82f6;border-radius:0 2px 2px 0; }
.notif-icon { width:36px;height:36px;background:rgba(16,185,129,.1);color:#10b981;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0; }
.notif-icon svg { width:18px;height:18px; }
.notif-body { flex:1; }
.notif-msg { font-size:.85rem;font-weight:500;color:#1e3a5f;margin:0 0 .25rem; }
.notif-amount { display:block;font-size:.9rem;font-weight:700;color:#10b981;margin-bottom:.2rem; }
.notif-time { font-size:.72rem;color:#94a3b8; }
.notif-overlay { position:fixed;inset:0;z-index:199; }
.loading-screen { display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1;gap:1rem;color:#64748b;font-size:.95rem;min-height:60vh; }
.loading-spinner { width:40px;height:40px;border:3px solid #e5e7eb;border-top-color:#3b82f6;border-radius:50%;animation:spin .7s linear infinite; }
@keyframes spin { to { transform:rotate(360deg); } }
.main-content > :not(.topbar):not(.notif-overlay):not(.loading-screen) { padding:1.5rem 2rem 2rem; }
</style>
