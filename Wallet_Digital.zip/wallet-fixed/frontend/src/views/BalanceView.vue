<script setup>
import { ref, onMounted } from 'vue'
import { useWalletStore } from '@/stores/wallet'

const walletStore = useWalletStore()

const showModal  = ref(false)
const modalType  = ref('')
const amount     = ref('')
const errorMsg   = ref('')
const successMsg = ref('')
const submitting = ref(false)

const formatCurrency = (v) =>
  new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(v)

const formatDate = (val) => {
  const d = val?.created_at ?? val
  if (!d) return ''
  return new Date(d).toLocaleDateString('es-CO', { day: 'numeric', month: 'short', year: 'numeric' })
}

const openModal = (type) => {
  modalType.value = type
  amount.value    = ''
  errorMsg.value  = ''
  showModal.value = true
}
const closeModal = () => { showModal.value = false; errorMsg.value = '' }

const handleSubmit = async () => {
  errorMsg.value  = ''
  submitting.value = true
  const monto = Number(amount.value)
  if (!monto || monto <= 0) { errorMsg.value = 'Ingresa un monto válido.'; submitting.value = false; return }

  let result
  if (modalType.value === 'deposit') {
    result = await walletStore.depositar(monto)
    if (result.ok) successMsg.value = `¡Recarga de ${formatCurrency(monto)} realizada!`
  } else {
    result = await walletStore.retirar(monto)
    if (result.ok) successMsg.value = `¡Retiro de ${formatCurrency(monto)} realizado!`
  }

  submitting.value = false
  if (!result.ok) { errorMsg.value = result.error; return }
  closeModal()
  setTimeout(() => { successMsg.value = '' }, 4000)
}

function tipoToType(t) {
  if (!t) return 'income'
  return (t.includes('recib') || t === 'recarga') ? 'income' : 'expense'
}

onMounted(() => {
  if (!walletStore.initialized) walletStore.cargarDatos()
})
</script>

<template>
  <div class="balance-content">
    <div class="page-header">
      <h1>Balance</h1>
      <p>Gestiona tu saldo y tus operaciones</p>
    </div>

    <div v-if="walletStore.loading && !walletStore.initialized" class="loading-state">
      <div class="spinner"></div>
      <span>Cargando tu wallet...</span>
    </div>

    <template v-else>
      <div v-if="successMsg" class="alert-success">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        {{ successMsg }}
      </div>

      <!-- Balance Card -->
      <div class="balance-main-card">
        <div class="balance-header">
          <span class="balance-label">Saldo disponible</span>
          <svg class="shield-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
        </div>
        <div class="balance-amount">{{ formatCurrency(walletStore.balance) }}</div>
        <div class="balance-actions">
          <button @click="openModal('deposit')" class="action-btn deposit">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
            Recargar
          </button>
          <button @click="openModal('withdraw')" class="action-btn withdraw">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
            Retirar
          </button>
        </div>
      </div>

      <!-- Stats -->
      <div class="stats-grid">
        <div class="stat-card income">
          <div class="stat-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
          </div>
          <div class="stat-info">
            <span class="stat-label">Ingresos</span>
            <span class="stat-value">{{ formatCurrency(walletStore.totalIngresos) }}</span>
          </div>
        </div>
        <div class="stat-card expense">
          <div class="stat-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>
          </div>
          <div class="stat-info">
            <span class="stat-label">Gastos</span>
            <span class="stat-value">{{ formatCurrency(walletStore.totalGastos) }}</span>
          </div>
        </div>
      </div>

      <!-- Actividad -->
      <div class="activity-section">
        <h2>Actividad reciente</h2>
        <div v-if="walletStore.transactions.length === 0" class="empty-activity">
          No hay movimientos aún.
        </div>
        <div v-else class="activity-list">
          <div v-for="tx in walletStore.recentActivity" :key="tx.id" class="activity-item">
            <div class="activity-icon" :class="tx.type">
              <svg v-if="tx.type === 'income'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
              <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
            </div>
            <div class="activity-info">
              <span class="activity-desc">{{ tx.description }}</span>
              <span class="activity-date">{{ formatDate(tx) }}</span>
            </div>
            <div class="activity-status">
              <span class="status-badge completed">Completado</span>
            </div>
            <div class="activity-amount" :class="tx.type">
              {{ tx.type === 'income' ? '+' : '-' }}{{ formatCurrency(tx.amount) }}
            </div>
          </div>
        </div>
      </div>
    </template>

    <!-- Modal -->
    <div v-if="showModal" class="modal-overlay" @click.self="closeModal">
      <div class="modal-content">
        <div class="modal-header">
          <h3>{{ modalType === 'deposit' ? 'Recargar saldo' : 'Retirar dinero' }}</h3>
          <button @click="closeModal" class="close-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div v-if="errorMsg" class="modal-error">{{ errorMsg }}</div>
        <div class="modal-form">
          <div class="form-group">
            <label>Monto</label>
            <input v-model="amount" type="number" min="1" placeholder="Ej: 100000" class="form-input">
          </div>
          <div class="form-actions">
            <button @click="closeModal" class="btn btn-secondary">Cancelar</button>
            <button @click="handleSubmit" class="btn btn-primary" :disabled="submitting">
              {{ submitting ? 'Procesando...' : (modalType === 'deposit' ? 'Recargar' : 'Retirar') }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.balance-content { max-width: 900px; }
.page-header { margin-bottom: 2rem; }
.page-header h1 { font-size: 1.75rem; font-weight: 700; color: #1e3a5f; margin-bottom: 0.25rem; }
.page-header p { color: #64748b; font-size: 0.95rem; }

.loading-state { display: flex; flex-direction: column; align-items: center; gap: 1rem; padding: 4rem; color: #64748b; }
.spinner { width: 40px; height: 40px; border: 3px solid #e5e7eb; border-top-color: #3b82f6; border-radius: 50%; animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.alert-success { display: flex; align-items: center; gap: .75rem; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.3); color: #065f46; padding: .875rem 1.25rem; border-radius: 12px; margin-bottom: 1.5rem; font-weight: 500; }
.alert-success svg { width:20px;height:20px;color:#10b981;flex-shrink:0; }

.balance-main-card { background: linear-gradient(135deg,#1e3a5f 0%,#0f2744 100%); border-radius: 16px; padding: 2rem; color: white; margin-bottom: 1.5rem; }
.balance-header { display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem; }
.balance-label { font-size:.875rem;color:rgba(255,255,255,.7); }
.shield-icon { width:24px;height:24px;color:rgba(255,255,255,.5); }
.balance-amount { font-size:2.5rem;font-weight:700;margin-bottom:1.5rem; }
.balance-actions { display:flex;gap:1rem; }
.action-btn { flex:1;display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.875rem 1.5rem;border-radius:12px;font-size:.95rem;font-weight:600;border:none;cursor:pointer;transition:all .2s; }
.action-btn svg { width:20px;height:20px; }
.action-btn.deposit { background:rgba(16,185,129,.2);color:#10b981;border:1px solid rgba(16,185,129,.3); }
.action-btn.deposit:hover { background:rgba(16,185,129,.3); }
.action-btn.withdraw { background:rgba(59,130,246,.2);color:#3b82f6;border:1px solid rgba(59,130,246,.3); }
.action-btn.withdraw:hover { background:rgba(59,130,246,.3); }

.stats-grid { display:grid;grid-template-columns:repeat(2,1fr);gap:1rem;margin-bottom:1.5rem; }
.stat-card { display:flex;align-items:center;gap:1rem;padding:1.25rem;background:white;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,.1); }
.stat-icon { width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center; }
.stat-icon svg { width:24px;height:24px; }
.stat-card.income .stat-icon { background:rgba(16,185,129,.1);color:#10b981; }
.stat-card.expense .stat-icon { background:rgba(239,68,68,.1);color:#ef4444; }
.stat-info { display:flex;flex-direction:column; }
.stat-label { font-size:.75rem;color:#64748b;margin-bottom:.25rem; }
.stat-value { font-size:1.25rem;font-weight:700;color:#1e3a5f; }

.activity-section { background:white;border-radius:12px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.1); }
.activity-section h2 { font-size:1rem;font-weight:600;color:#1e3a5f;margin-bottom:1rem; }
.empty-activity { color:#94a3b8;font-size:.875rem;text-align:center;padding:2rem 0; }
.activity-list { display:flex;flex-direction:column;gap:.75rem; }
.activity-item { display:flex;align-items:center;gap:1rem;padding:1rem;background:#f8fafc;border-radius:12px; }
.activity-icon { width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center; }
.activity-icon svg { width:22px;height:22px; }
.activity-icon.income { background:rgba(16,185,129,.1);color:#10b981; }
.activity-icon.expense { background:rgba(239,68,68,.1);color:#ef4444; }
.activity-info { flex:1;display:flex;flex-direction:column; }
.activity-desc { font-weight:600;color:#1e3a5f;font-size:.95rem; }
.activity-date { font-size:.75rem;color:#64748b; }
.activity-status { margin-right:.5rem; }
.status-badge { padding:.25rem .75rem;border-radius:20px;font-size:.75rem;font-weight:600; }
.status-badge.completed { background:rgba(16,185,129,.1);color:#10b981; }
.activity-amount { font-weight:700;font-size:.95rem; }
.activity-amount.income { color:#10b981; }
.activity-amount.expense { color:#ef4444; }

.modal-overlay { position:fixed;inset:0;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;z-index:1000; }
.modal-content { background:white;border-radius:16px;width:90%;max-width:400px;padding:1.5rem; }
.modal-header { display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem; }
.modal-header h3 { font-size:1.25rem;font-weight:600;color:#1e3a5f; }
.close-btn { background:transparent;border:none;color:#64748b;cursor:pointer;padding:.5rem; }
.close-btn svg { width:20px;height:20px; }
.modal-error { background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#b91c1c;padding:.75rem 1rem;border-radius:10px;font-size:.875rem;margin-bottom:1rem; }
.modal-form { display:flex;flex-direction:column;gap:1rem; }
.form-group { display:flex;flex-direction:column;gap:.5rem; }
.form-group label { font-size:.875rem;font-weight:500;color:#374151; }
.form-input { padding:.875rem;border:1px solid #e5e7eb;border-radius:10px;font-size:1rem;transition:border-color .2s; }
.form-input:focus { outline:none;border-color:#3b82f6; }
.form-actions { display:flex;gap:1rem;margin-top:.5rem; }
.btn { flex:1;padding:.875rem;border-radius:10px;font-size:.95rem;font-weight:600;border:none;cursor:pointer;transition:all .2s; }
.btn-secondary { background:#f3f4f6;color:#374151; }
.btn-secondary:hover { background:#e5e7eb; }
.btn-primary { background:#3b82f6;color:white; }
.btn-primary:hover:not(:disabled) { background:#2563eb; }
.btn-primary:disabled { opacity:.6;cursor:not-allowed; }
</style>
