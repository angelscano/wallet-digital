import api from './api'

export const walletService = {
  async getWallet() {
    const res = await api.get('/wallet')
    return res.data
  },
  async recargar(monto, descripcion = '') {
    const res = await api.post('/wallet/recargar', { monto, descripcion })
    return res.data
  },
  async retirar(monto, descripcion = '') {
    const res = await api.post('/wallet/retirar', { monto, descripcion })
    return res.data
  },
  async transferir(emailDestino, monto, descripcion = '', nombreDestinatario = '') {
    const res = await api.post('/wallet/transferir', { emailDestino, monto, descripcion, nombreDestinatario })
    return res.data
  },
  async historial(page = 1, limit = 20, tipo = '') {
    const params = { page, limit }
    if (tipo) params.tipo = tipo
    const res = await api.get('/wallet/historial', { params })
    return res.data
  },
  async destinatariosRecientes() {
    const res = await api.get('/wallet/destinatarios-recientes')
    return res.data
  },
  async notificaciones() {
    const res = await api.get('/wallet/notificaciones')
    return res.data
  },
  async marcarNotificacionesLeidas() {
    const res = await api.patch('/wallet/notificaciones/leer')
    return res.data
  }
}
