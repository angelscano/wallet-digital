import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authService } from '@/services/auth.service'
import router from '@/router'
import { useWalletStore } from '@/stores/wallet'

export const useAuthStore = defineStore('auth', () => {
  const usuario = ref(null)
  const token   = ref(localStorage.getItem('token') || null)
  const loading = ref(false)
  const error   = ref(null)

  const isAuthenticated = computed(() => !!token.value)
  const nombreUsuario   = computed(() => usuario.value?.nombre || '')
  const rolUsuario      = computed(() => usuario.value?.rol || '')
  const isAdmin         = computed(() => usuario.value?.rol === 'admin')

  function _resetWallet() {
    // Se llama dentro de acciones (no en el setup top-level), así Pinia ya está activa
    try { useWalletStore().reset() } catch (_) {}
  }

  async function register(userData) {
    loading.value = true
    error.value   = null
    try {
      _resetWallet()
      const response  = await authService.register(userData)
      token.value     = response.data.token
      usuario.value   = response.data.usuario
      localStorage.setItem('token', response.data.token)
      router.push({ name: 'dashboard' })
      return response
    } catch (err) {
      error.value = err.message || 'Error al registrar usuario'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function login(credentials) {
    loading.value = true
    error.value   = null
    try {
      _resetWallet()
      const response  = await authService.login(credentials)
      token.value     = response.data.token
      usuario.value   = response.data.usuario
      localStorage.setItem('token', response.data.token)
      const redirect  = router.currentRoute.value.query.redirect
      router.push(redirect || { name: 'dashboard' })
      return response
    } catch (err) {
      error.value = err.message || 'Error al iniciar sesión'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function fetchProfile() {
    if (!token.value) return
    loading.value = true
    try {
      const response = await authService.getProfile()
      usuario.value  = response.data.usuario
    } catch (err) {
      logout()
    } finally {
      loading.value = false
    }
  }

  function logout() {
    _resetWallet()
    token.value   = null
    usuario.value = null
    localStorage.removeItem('token')
    router.push({ name: 'login' })
  }

  function clearError() { error.value = null }

  if (token.value) { fetchProfile() }

  return {
    usuario, token, loading, error,
    isAuthenticated, nombreUsuario, rolUsuario, isAdmin,
    register, login, logout, fetchProfile, clearError
  }
})
