import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { walletService } from '@/services/wallet.service'

export const useWalletStore = defineStore('wallet', () => {
  const balance          = ref(0)
  const transactions     = ref([])
  const recentRecipients = ref([])
  const notifications    = ref([])
  const loading          = ref(true)
  const initialized      = ref(false)

  const unreadNotifications = computed(() => notifications.value.filter(n => !n.leida && !n.read).length)
  const totalIngresos = computed(() =>
    transactions.value.filter(t => t.type === 'income' || t.tipo?.includes('recib') || t.tipo === 'recarga')
      .reduce((s, t) => s + Number(t.amount ?? t.monto ?? 0), 0)
  )
  const totalGastos = computed(() =>
    transactions.value.filter(t => t.type === 'expense' || t.tipo?.includes('enviada') || t.tipo === 'retiro')
      .reduce((s, t) => s + Number(t.amount ?? t.monto ?? 0), 0)
  )
  const recentActivity = computed(() =>
    [...transactions.value]
      .sort((a, b) => new Date(b.created_at ?? b.date) - new Date(a.created_at ?? a.date))
      .slice(0, 5)
      .map(normalizeTransaction)
  )

  // Normaliza transacciones del backend al formato del frontend
  function normalizeTransaction(t) {
    if (t.tipo) {
      return {
        id:          t.id,
        type:        t.tipo.includes('recib') || t.tipo === 'recarga' ? 'income' : 'expense',
        description: t.descripcion || t.tipo,
        amount:      Number(t.monto),
        date:        t.created_at ? t.created_at.split('T')[0] : '',
        time:        t.created_at ? t.created_at.split('T')[1]?.slice(0, 5) : '',
        status:      t.estado === 'completada' ? 'completed' : t.estado,
        category:    t.categoria
      }
    }
    return t
  }

  // ── Cargar datos desde la API ────────────────────────────
  async function cargarDatos() {
    if (loading.value && initialized.value) return  // ya está cargando una segunda vez, ignorar
    loading.value = true
    try {
      const [walletRes, histRes, recientesRes, notifsRes] = await Promise.all([
        walletService.getWallet(),
        walletService.historial(1, 50),
        walletService.destinatariosRecientes(),
        walletService.notificaciones()
      ])
      balance.value          = Number(walletRes.data.wallet.saldo)
      transactions.value     = histRes.data.transacciones || []
      recentRecipients.value = (recientesRes.data.destinatarios || []).map(r => ({
        id:     r.email,
        name:   r.nombre,
        email:  r.email,
        avatar: r.avatar || r.nombre?.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
      }))
      notifications.value    = notifsRes.data.notificaciones || []
      initialized.value      = true
    } catch (err) {
      console.error('Error cargando wallet:', err)
    } finally {
      loading.value = false
    }
  }

  // ── Reset al cambiar de cuenta ───────────────────────────
  function reset() {
    balance.value          = 0
    transactions.value     = []
    recentRecipients.value = []
    notifications.value    = []
    initialized.value      = false
    loading.value          = true
  }

  // ── Recargar saldo ───────────────────────────────────────
  async function depositar(monto, descripcion = '') {
    const n = Number(monto)
    if (!n || n <= 0) return { ok: false, error: 'Monto inválido' }
    try {
      const res = await walletService.recargar(n, descripcion)
      balance.value = Number(res.data.wallet.saldo)
      transactions.value.unshift(res.data.transaccion)
      return { ok: true }
    } catch (err) {
      return { ok: false, error: err.message || 'Error al recargar' }
    }
  }

  // ── Retirar saldo ────────────────────────────────────────
  async function retirar(monto, descripcion = '') {
    const n = Number(monto)
    if (!n || n <= 0) return { ok: false, error: 'Monto inválido' }
    try {
      const res = await walletService.retirar(n, descripcion)
      balance.value = Number(res.data.wallet.saldo)
      transactions.value.unshift(res.data.transaccion)
      return { ok: true }
    } catch (err) {
      return { ok: false, error: err.message || 'Error al retirar' }
    }
  }

  // ── Transferir a otra cuenta ─────────────────────────────
  async function transferir(monto, destinatario, descripcion = '') {
    const n = Number(monto)
    if (!n || n <= 0) return { ok: false, error: 'Monto inválido' }
    try {
      const res = await walletService.transferir(
        destinatario.email, n, descripcion, destinatario.name
      )
      // Recargar saldo y transacciones desde la respuesta
      balance.value = Number(res.data.walletOrigen.saldo)
      // Agregar destinatario a recientes localmente también
      const avatar = destinatario.name
        ? destinatario.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
        : destinatario.email.slice(0, 2).toUpperCase()
      const idx = recentRecipients.value.findIndex(r => r.email === destinatario.email)
      if (idx !== -1) recentRecipients.value.splice(idx, 1)
      recentRecipients.value.unshift({ id: destinatario.email, name: destinatario.name, email: destinatario.email, avatar })
      if (recentRecipients.value.length > 5) recentRecipients.value.pop()
      // Recargar historial completo para tener la transacción nueva
      await recargarHistorial()
      return { ok: true }
    } catch (err) {
      return { ok: false, error: err.message || 'Error al transferir' }
    }
  }

  async function recargarHistorial() {
    try {
      const res = await walletService.historial(1, 50)
      transactions.value = res.data.transacciones || []
    } catch (_) {}
  }

  async function marcarNotificacionesLeidas() {
    notifications.value.forEach(n => { n.leida = true; n.read = true })
    try { await walletService.marcarNotificacionesLeidas() } catch (_) {}
  }

  // ── Polling de notificaciones (cada 15s) ─────────────────
  let _pollInterval = null
  function iniciarPolling() {
    if (_pollInterval) return
    _pollInterval = setInterval(async () => {
      try {
        const res = await walletService.notificaciones()
        const nuevas = res.data.notificaciones || []
        // Detectar notificaciones nuevas no leídas
        const idsActuales = new Set(notifications.value.map(n => n.id))
        const nuevasNoLeidas = nuevas.filter(n => !idsActuales.has(n.id) && !n.leida)
        if (nuevasNoLeidas.length > 0) {
          notifications.value = nuevas
          // También actualizar saldo si recibimos dinero
          const walletRes = await walletService.getWallet()
          balance.value = Number(walletRes.data.wallet.saldo)
          await recargarHistorial()
        }
      } catch (_) {}
    }, 15000)
  }
  function detenerPolling() {
    if (_pollInterval) { clearInterval(_pollInterval); _pollInterval = null }
  }

  return {
    balance, transactions, recentRecipients, notifications, loading, initialized,
    unreadNotifications, totalIngresos, totalGastos, recentActivity,
    reset, cargarDatos, depositar, retirar, transferir,
    marcarNotificacionesLeidas, iniciarPolling, detenerPolling, recargarHistorial
  }
})
