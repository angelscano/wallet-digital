const bcrypt      = require('bcrypt')
const jwt         = require('jsonwebtoken')
const UsuarioModel = require('../models/usuario.model')
const WalletModel  = require('../models/wallet.model')
const { AppError } = require('../middlewares/errorHandler')

class AuthService {
  static async registrar(userData) {
    const { nombre, email, password } = userData

    const existeEmail = await UsuarioModel.existeEmail(email)
    if (existeEmail) throw new AppError('El email ya está registrado', 409)

    const saltRounds  = 12
    const passwordHash = await bcrypt.hash(password, saltRounds)

    const nuevoUsuario = await UsuarioModel.crear({ nombre, email, password: passwordHash, rol: 'usuario' })

    // Crear wallet automáticamente al registrar
    await WalletModel.crearParaUsuario(nuevoUsuario.id)

    const token = this.generarToken(nuevoUsuario)
    return { usuario: nuevoUsuario, token }
  }

  static async login(email, password) {
    const usuario = await UsuarioModel.buscarPorEmail(email)
    if (!usuario) throw new AppError('Credenciales inválidas', 401)

    const passwordValido = await bcrypt.compare(password, usuario.password)
    if (!passwordValido) throw new AppError('Credenciales inválidas', 401)

    const token = this.generarToken(usuario)
    const { password: _, ...usuarioSinPassword } = usuario
    return { usuario: usuarioSinPassword, token }
  }

  static generarToken(usuario) {
    return jwt.sign(
      { id: usuario.id, email: usuario.email, rol: usuario.rol },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    )
  }

  static verificarToken(token) {
    try {
      return jwt.verify(token, process.env.JWT_SECRET)
    } catch {
      throw new AppError('Token inválido o expirado', 401)
    }
  }
}

module.exports = AuthService
