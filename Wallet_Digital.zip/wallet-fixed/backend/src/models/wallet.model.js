const { pool } = require('../config/database')

class WalletModel {
  static async crearParaUsuario(usuarioId) {
    const { rows } = await pool.query(
      `INSERT INTO wallets (usuario_id) VALUES ($1) RETURNING *`,
      [usuarioId]
    )
    return rows[0]
  }

  static async buscarPorUsuarioId(usuarioId) {
    const { rows } = await pool.query(
      `SELECT * FROM wallets WHERE usuario_id = $1`,
      [usuarioId]
    )
    return rows[0] || null
  }

  static async obtenerSaldo(usuarioId) {
    const { rows } = await pool.query(
      `SELECT saldo FROM wallets WHERE usuario_id = $1`,
      [usuarioId]
    )
    return rows[0]?.saldo ?? null
  }

  static async recargar(usuarioId, monto, descripcion = 'Recarga de saldo') {
    const client = await pool.connect()
    try {
      await client.query('BEGIN')
      const { rows: [wallet] } = await client.query(
        `UPDATE wallets SET saldo = saldo + $1, updated_at = NOW()
         WHERE usuario_id = $2 RETURNING *`,
        [monto, usuarioId]
      )
      const { rows: [tx] } = await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'recarga', $2, $3, 'recarga') RETURNING *`,
        [wallet.id, monto, descripcion]
      )
      await client.query('COMMIT')
      return { wallet, transaccion: tx }
    } catch (err) {
      await client.query('ROLLBACK')
      throw err
    } finally {
      client.release()
    }
  }

  static async retirar(usuarioId, monto, descripcion = 'Retiro de saldo') {
    const client = await pool.connect()
    try {
      await client.query('BEGIN')
      const { rows: [wallet] } = await client.query(
        `UPDATE wallets SET saldo = saldo - $1, updated_at = NOW()
         WHERE usuario_id = $2 AND saldo >= $1 RETURNING *`,
        [monto, usuarioId]
      )
      if (!wallet) throw new Error('Saldo insuficiente')
      const { rows: [tx] } = await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'retiro', $2, $3, 'retiro') RETURNING *`,
        [wallet.id, monto, descripcion]
      )
      await client.query('COMMIT')
      return { wallet, transaccion: tx }
    } catch (err) {
      await client.query('ROLLBACK')
      throw err
    } finally {
      client.release()
    }
  }

  /**
   * Transferencia atómica entre dos wallets.
   * Guarda nombre+email en transferencias, destinatarios_recientes y notificaciones.
   */
  static async transferir(usuarioOrigenId, emailDestino, monto, descripcion = '', nombreDestinatario = '') {
    const client = await pool.connect()
    try {
      await client.query('BEGIN')

      // Obtener datos del remitente
      const { rows: [usuarioOrigen] } = await client.query(
        `SELECT u.id, u.nombre, u.email, w.id AS wallet_id
         FROM usuarios u JOIN wallets w ON w.usuario_id = u.id
         WHERE u.id = $1`,
        [usuarioOrigenId]
      )

      // Buscar destinatario por email (crear wallet si no tiene)
      const { rows: [usuarioDestBase] } = await client.query(
        `SELECT id, nombre, email FROM usuarios WHERE email = $1`,
        [emailDestino]
      )
      if (!usuarioDestBase) throw new Error('Usuario destino no encontrado')

      // Asegurar que el destinatario tiene wallet (crearla si no existe)
      await client.query(
        `INSERT INTO wallets (usuario_id) VALUES ($1) ON CONFLICT (usuario_id) DO NOTHING`,
        [usuarioDestBase.id]
      )

      // Obtener wallet_id del destinatario
      const { rows: [usuarioDest] } = await client.query(
        `SELECT u.id, u.nombre, u.email, w.id AS wallet_id
         FROM usuarios u JOIN wallets w ON w.usuario_id = u.id
         WHERE u.email = $1`,
        [emailDestino]
      )
      if (!usuarioDest) throw new Error('Usuario destino no encontrado')
      if (usuarioDest.id === usuarioOrigenId) throw new Error('No puedes transferirte a ti mismo')

      const nombreDest = nombreDestinatario || usuarioDest.nombre

      // Descontar del origen
      const { rows: [walletOrigen] } = await client.query(
        `UPDATE wallets SET saldo = saldo - $1, updated_at = NOW()
         WHERE usuario_id = $2 AND saldo >= $1 RETURNING *`,
        [monto, usuarioOrigenId]
      )
      if (!walletOrigen) throw new Error('Saldo insuficiente')

      // Abonar al destino
      await client.query(
        `UPDATE wallets SET saldo = saldo + $1, updated_at = NOW() WHERE id = $2`,
        [monto, usuarioDest.wallet_id]
      )

      // Registrar transferencia con nombres y emails
      const { rows: [transf] } = await client.query(
        `INSERT INTO transferencias
           (wallet_origen_id, wallet_destino_id, nombre_destinatario, email_destinatario,
            nombre_remitente, email_remitente, monto, descripcion)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
        [walletOrigen.id, usuarioDest.wallet_id, nombreDest, emailDestino,
         usuarioOrigen.nombre, usuarioOrigen.email, monto, descripcion]
      )

      // Transacciones historial
      const descEnviada = descripcion
        ? `Transferencia a ${nombreDest} — ${descripcion}`
        : `Transferencia enviada a ${nombreDest}`
      const descRecibida = descripcion
        ? `Transferencia de ${usuarioOrigen.nombre} — ${descripcion}`
        : `Transferencia recibida de ${usuarioOrigen.nombre}`

      await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'transferencia_enviada', $2, $3, 'transferencia')`,
        [walletOrigen.id, monto, descEnviada]
      )
      await client.query(
        `INSERT INTO transacciones (wallet_id, tipo, monto, descripcion, categoria)
         VALUES ($1, 'transferencia_recibida', $2, $3, 'transferencia')`,
        [usuarioDest.wallet_id, monto, descRecibida]
      )

      // Actualizar destinatarios_recientes del remitente
      const avatarDest = nombreDest.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
      await client.query(
        `INSERT INTO destinatarios_recientes (usuario_id, nombre, email, avatar, ultima_vez)
         VALUES ($1, $2, $3, $4, NOW())
         ON CONFLICT (usuario_id, email)
         DO UPDATE SET nombre = $2, avatar = $4, ultima_vez = NOW()`,
        [usuarioOrigenId, nombreDest, emailDestino, avatarDest]
      )

      // Crear notificación para el destinatario
      const msgNotif = `${usuarioOrigen.nombre} te envió $${Number(monto).toLocaleString('es-CO')}`
      await client.query(
        `INSERT INTO notificaciones (usuario_id, tipo, mensaje, monto, de_usuario)
         VALUES ($1, 'transferencia_recibida', $2, $3, $4)`,
        [usuarioDest.id, msgNotif, monto, usuarioOrigen.nombre]
      )

      await client.query('COMMIT')
      return { walletOrigen, transferencia: transf, destinatario: { nombre: nombreDest, email: emailDestino } }
    } catch (err) {
      await client.query('ROLLBACK')
      throw err
    } finally {
      client.release()
    }
  }

  // Historial paginado
  static async historial(usuarioId, { page = 1, limit = 20, tipo } = {}) {
    const offset = (page - 1) * limit
    const params = [usuarioId, limit, offset]
    let filtro = ''
    if (tipo) { filtro = `AND t.tipo = $4`; params.push(tipo) }

    const { rows } = await pool.query(
      `SELECT t.* FROM transacciones t
       JOIN wallets w ON w.id = t.wallet_id
       WHERE w.usuario_id = $1 ${filtro}
       ORDER BY t.created_at DESC
       LIMIT $2 OFFSET $3`,
      params
    )
    const { rows: [{ total }] } = await pool.query(
      `SELECT COUNT(*) AS total FROM transacciones t
       JOIN wallets w ON w.id = t.wallet_id
       WHERE w.usuario_id = $1 ${tipo ? `AND t.tipo = $2` : ''}`,
      tipo ? [usuarioId, tipo] : [usuarioId]
    )
    return { transacciones: rows, total: parseInt(total), page, limit }
  }

  // Destinatarios recientes del usuario
  static async destinatariosRecientes(usuarioId, limit = 5) {
    const { rows } = await pool.query(
      `SELECT nombre, email, avatar FROM destinatarios_recientes
       WHERE usuario_id = $1
       ORDER BY ultima_vez DESC
       LIMIT $2`,
      [usuarioId, limit]
    )
    return rows
  }

  // Notificaciones del usuario
  static async notificaciones(usuarioId) {
    const { rows } = await pool.query(
      `SELECT * FROM notificaciones WHERE usuario_id = $1 ORDER BY created_at DESC LIMIT 50`,
      [usuarioId]
    )
    return rows
  }

  // Marcar notificaciones como leídas
  static async marcarNotificacionesLeidas(usuarioId) {
    await pool.query(
      `UPDATE notificaciones SET leida = true WHERE usuario_id = $1 AND leida = false`,
      [usuarioId]
    )
  }
}

module.exports = WalletModel
