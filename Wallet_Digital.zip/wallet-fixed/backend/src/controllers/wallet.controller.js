const WalletService = require('../services/wallet.service')

class WalletController {
  static async obtenerWallet(req, res, next) {
    try {
      const wallet = await WalletService.obtenerSaldo(req.usuario.id)
      res.json({ success: true, data: { wallet } })
    } catch (err) { next(err) }
  }

  static async recargar(req, res, next) {
    try {
      const { monto, descripcion } = req.body
      const result = await WalletService.recargar(req.usuario.id, Number(monto), descripcion)
      res.json({ success: true, message: 'Recarga exitosa', data: result })
    } catch (err) { next(err) }
  }

  static async retirar(req, res, next) {
    try {
      const { monto, descripcion } = req.body
      const result = await WalletService.retirar(req.usuario.id, Number(monto), descripcion)
      res.json({ success: true, message: 'Retiro exitoso', data: result })
    } catch (err) { next(err) }
  }

  static async transferir(req, res, next) {
    try {
      const { emailDestino, monto, descripcion, nombreDestinatario } = req.body
      const result = await WalletService.transferir(
        req.usuario.id, emailDestino, Number(monto), descripcion, nombreDestinatario
      )
      res.json({ success: true, message: 'Transferencia exitosa', data: result })
    } catch (err) { next(err) }
  }

  static async historial(req, res, next) {
    try {
      const { page = 1, limit = 20, tipo } = req.query
      const result = await WalletService.historial(req.usuario.id, { page: Number(page), limit: Number(limit), tipo })
      res.json({ success: true, data: result })
    } catch (err) { next(err) }
  }

  static async destinatariosRecientes(req, res, next) {
    try {
      const result = await WalletService.destinatariosRecientes(req.usuario.id)
      res.json({ success: true, data: { destinatarios: result } })
    } catch (err) { next(err) }
  }

  static async notificaciones(req, res, next) {
    try {
      const result = await WalletService.notificaciones(req.usuario.id)
      res.json({ success: true, data: { notificaciones: result } })
    } catch (err) { next(err) }
  }

  static async marcarNotificacionesLeidas(req, res, next) {
    try {
      await WalletService.marcarNotificacionesLeidas(req.usuario.id)
      res.json({ success: true, message: 'Notificaciones marcadas como leídas' })
    } catch (err) { next(err) }
  }
}

module.exports = WalletController
