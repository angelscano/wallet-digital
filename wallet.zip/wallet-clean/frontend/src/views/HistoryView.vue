<script setup>
import { ref, computed } from 'vue'
import { useWalletStore } from '@/stores/wallet'
import { useFormat } from '@/composables/useFormat'

const walletStore = useWalletStore()
const { formatCurrency, formatDate } = useFormat()

const filterType  = ref('all')
const searchQuery = ref('')

function normalize(t) {
  if (t.tipo) {
    const isIncome = t.tipo.includes('recib') || t.tipo === 'recarga'
    const d = t.created_at ? new Date(t.created_at) : null
    return {
      id:          t.id,
      type:        isIncome ? 'income' : 'expense',
      description: t.descripcion || t.tipo,
      amount:      Number(t.monto),
      date:        d ? d.toISOString().split('T')[0] : '',
      time:        d ? d.toTimeString().slice(0, 5) : '',
      category:    t.categoria,
      rawDate:     d
    }
  }
  return { ...t, rawDate: t.date ? new Date(t.date) : null }
}

const filteredTransactions = computed(() => {
  let result = walletStore.transactions.map(normalize)
    .sort((a, b) => (b.rawDate || 0) - (a.rawDate || 0))

  if (filterType.value !== 'all')
    result = result.filter(t => t.type === filterType.value)

  if (searchQuery.value) {
    const q = searchQuery.value.toLowerCase()
    result = result.filter(t =>
      (t.description || '').toLowerCase().includes(q) ||
      (t.category    || '').toLowerCase().includes(q)
    )
  }
  return result
})
</script>

<template>
  <div class="history-content">
    <div class="page-header">
      <h1>Historial</h1>
      <p>Todas tus transacciones en un solo lugar</p>
    </div>

    <div class="summary-cards">
      <div class="summary-card income">
        <div class="summary-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
        </div>
        <div class="summary-info">
          <span class="summary-label">Ingresos</span>
          <span class="summary-value">{{ formatCurrency(walletStore.totalIngresos) }}</span>
        </div>
      </div>
      <div class="summary-card expense">
        <div class="summary-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>
        </div>
        <div class="summary-info">
          <span class="summary-label">Gastos</span>
          <span class="summary-value">{{ formatCurrency(walletStore.totalGastos) }}</span>
        </div>
      </div>
    </div>

    <div class="filters-section">
      <div class="search-box">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input v-model="searchQuery" type="text" placeholder="Buscar transacción..." class="search-input">
      </div>
      <div class="filter-tabs">
        <button @click="filterType = 'all'"     :class="{ active: filterType === 'all' }">Todas</button>
        <button @click="filterType = 'income'"  :class="{ active: filterType === 'income' }">Ingresos</button>
        <button @click="filterType = 'expense'" :class="{ active: filterType === 'expense' }">Gastos</button>
      </div>
    </div>

    <div class="transactions-container">
      <div class="transactions-list">
        <div v-for="tx in filteredTransactions" :key="tx.id" class="transaction-card">
          <div class="transaction-icon" :class="tx.type">
            <svg v-if="tx.type === 'income'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
            <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
          </div>
          <div class="transaction-details">
            <span class="transaction-desc">{{ tx.description }}</span>
            <div class="transaction-meta">
              <span class="transaction-date">{{ formatDate(tx.date) }}</span>
              <span v-if="tx.time" class="transaction-time">{{ tx.time }}</span>
              <span v-if="tx.category" class="transaction-category">{{ tx.category }}</span>
            </div>
          </div>
          <div class="transaction-amount" :class="tx.type">
            {{ tx.type === 'income' ? '+' : '-' }}{{ formatCurrency(tx.amount) }}
          </div>
        </div>
      </div>

      <div v-if="filteredTransactions.length === 0" class="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <p>No se encontraron transacciones</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.history-content { max-width: 900px; }
.page-header { margin-bottom: 2rem; }
.page-header h1 { font-size: 1.75rem; font-weight: 700; color: #1e3a5f; margin-bottom: 0.25rem; }
.page-header p  { color: #64748b; font-size: 0.95rem; }

.summary-cards { display:grid;grid-template-columns:repeat(2,1fr);gap:1rem;margin-bottom:1.5rem; }
.summary-card { display:flex;align-items:center;gap:1rem;padding:1.25rem;background:white;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,.1); }
.summary-icon { width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center; }
.summary-icon svg { width:24px;height:24px; }
.summary-card.income  .summary-icon { background:rgba(16,185,129,.1);color:#10b981; }
.summary-card.expense .summary-icon { background:rgba(239,68,68,.1);color:#ef4444; }
.summary-info { display:flex;flex-direction:column; }
.summary-label { font-size:.75rem;color:#64748b;margin-bottom:.25rem; }
.summary-value { font-size:1.25rem;font-weight:700;color:#1e3a5f; }

.filters-section { display:flex;gap:1rem;margin-bottom:1.5rem;align-items:center; }
.search-box { flex:1;display:flex;align-items:center;gap:.75rem;padding:.75rem 1rem;background:white;border-radius:10px;border:1px solid #e5e7eb; }
.search-box svg { width:20px;height:20px;color:#64748b; }
.search-input { flex:1;border:none;background:transparent;font-size:.95rem;color:#374151; }
.search-input:focus { outline:none; }
.filter-tabs { display:flex;gap:.5rem;background:white;padding:.25rem;border-radius:10px;border:1px solid #e5e7eb; }
.filter-tabs button { padding:.5rem 1rem;border:none;background:transparent;border-radius:8px;font-size:.875rem;font-weight:500;color:#64748b;cursor:pointer;transition:all .2s; }
.filter-tabs button:hover { color:#374151; }
.filter-tabs button.active { background:#3b82f6;color:white; }

.transactions-container { background:white;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,.1);overflow:hidden; }
.transactions-list { display:flex;flex-direction:column; }
.transaction-card { display:flex;align-items:center;gap:1rem;padding:1.25rem;border-bottom:1px solid #f1f5f9;transition:background .2s; }
.transaction-card:hover { background:#f8fafc; }
.transaction-card:last-child { border-bottom:none; }
.transaction-icon { width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0; }
.transaction-icon svg { width:24px;height:24px; }
.transaction-icon.income  { background:rgba(16,185,129,.1);color:#10b981; }
.transaction-icon.expense { background:rgba(239,68,68,.1);color:#ef4444; }
.transaction-details { flex:1;display:flex;flex-direction:column;gap:.25rem; }
.transaction-desc { font-weight:600;color:#1e3a5f; }
.transaction-meta { display:flex;gap:.75rem;align-items:center; }
.transaction-date,.transaction-time { font-size:.75rem;color:#64748b; }
.transaction-category { font-size:.7rem;padding:.125rem .5rem;background:#f1f5f9;border-radius:4px;color:#64748b;text-transform:capitalize; }
.transaction-amount { font-weight:700;font-size:1rem; }
.transaction-amount.income  { color:#10b981; }
.transaction-amount.expense { color:#ef4444; }

.empty-state { display:flex;flex-direction:column;align-items:center;justify-content:center;padding:3rem;color:#64748b; }
.empty-state svg { width:48px;height:48px;margin-bottom:1rem;opacity:.5; }
.empty-state p { font-size:.95rem; }
</style>
