<script setup>
import { ref, computed, onMounted } from 'vue'
import { useWalletStore } from '@/stores/wallet'
import { useFormat } from '@/composables/useFormat'

const walletStore = useWalletStore()
const { formatCurrency } = useFormat()

const recipientEmail    = ref('')
const recipientName     = ref('')
const amount            = ref('')
const description       = ref('')
const step              = ref(1)
const isSubmitting      = ref(false)
const errorMsg          = ref('')
const successMsg        = ref('')
const selectedRecipient = ref(null)
const confirmData       = ref(null)

const recentRecipients = computed(() => walletStore.recentRecipients)

const selectRecipient = (r) => {
  selectedRecipient.value = r
  recipientEmail.value    = r.email
  recipientName.value     = r.name
  step.value = 2
}

const goBack = () => {
  if (step.value > 1) { step.value--; if (step.value === 1) { selectedRecipient.value = null; confirmData.value = null } }
  errorMsg.value = ''
}

const proceedToConfirm = () => {
  errorMsg.value = ''
  const n = Number(amount.value)
  if (!n || n <= 0)            { errorMsg.value = 'Ingresa un monto válido.'; return }
  if (n > walletStore.balance) { errorMsg.value = 'Saldo insuficiente para esta transferencia.'; return }
  if (!recipientEmail.value)   { errorMsg.value = 'Ingresa el correo del destinatario.'; return }

  const name      = recipientName.value.trim() || recipientEmail.value
  const avatar    = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
  const recipient = selectedRecipient.value || { name, email: recipientEmail.value, avatar }
  confirmData.value = { recipient, amount: n, description: description.value }
  step.value = 3
}

const handleSubmit = async () => {
  isSubmitting.value = true
  errorMsg.value     = ''
  const result = await walletStore.transferir(
    confirmData.value.amount,
    confirmData.value.recipient,
    confirmData.value.description
  )
  isSubmitting.value = false
  if (!result.ok) { errorMsg.value = result.error || 'No se pudo procesar la transferencia.'; return }
  successMsg.value = `Transferencia de ${formatCurrency(confirmData.value.amount)} enviada a ${confirmData.value.recipient.name}`
  resetForm()
  setTimeout(() => { successMsg.value = '' }, 5000)
}

const resetForm = () => {
  step.value = 1; recipientEmail.value = ''; recipientName.value = ''
  amount.value = ''; description.value = ''; selectedRecipient.value = null; confirmData.value = null
}

onMounted(() => { if (!walletStore.initialized) walletStore.cargarDatos() })
</script>

<template>
  <div class="transfer-content">
    <div class="page-header">
      <h1>Transferir</h1>
      <p>Envía dinero a otros usuarios de Wallet</p>
    </div>

    <div v-if="successMsg" class="alert-success">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
      {{ successMsg }}
    </div>

    <div class="balance-bar">
      <span>Saldo disponible:</span>
      <strong>{{ formatCurrency(walletStore.balance) }}</strong>
    </div>

    <div class="progress-steps">
      <div class="step" :class="{ active: step >= 1, completed: step > 1 }"><div class="step-number">1</div><span>Destinatario</span></div>
      <div class="step-line" :class="{ active: step > 1 }"></div>
      <div class="step" :class="{ active: step >= 2, completed: step > 2 }"><div class="step-number">2</div><span>Monto</span></div>
      <div class="step-line" :class="{ active: step > 2 }"></div>
      <div class="step" :class="{ active: step >= 3 }"><div class="step-number">3</div><span>Confirmar</span></div>
    </div>

    <!-- Step 1: Destinatario -->
    <div v-if="step === 1" class="step-content">
      <div class="form-card">
        <h2>Selecciona un destinatario</h2>
        <p class="form-subtitle">Elige de tus transferencias recientes o ingresa un nuevo destinatario</p>

        <div v-if="recentRecipients.length > 0">
          <p class="section-label">Recientes</p>
          <div class="recent-recipients">
            <div v-for="r in recentRecipients" :key="r.id" @click="selectRecipient(r)" class="recipient-card">
              <div class="recipient-avatar">{{ r.avatar }}</div>
              <div class="recipient-info"><span class="recipient-name">{{ r.name }}</span><span class="recipient-email">{{ r.email }}</span></div>
              <svg class="recipient-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </div>
          </div>
        </div>
        <div v-else class="empty-recents">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <p>Aún no tienes destinatarios recientes.</p>
        </div>

        <div class="divider"><span>o ingresa un nuevo destinatario</span></div>
        <form @submit.prevent="step = 2" class="email-form">
          <div class="form-group">
            <label>Nombre del destinatario</label>
            <input v-model="recipientName" type="text" placeholder="Ej: María García" class="form-input">
          </div>
          <div class="form-group">
            <label>Correo del destinatario <span class="required">*</span></label>
            <input v-model="recipientEmail" type="email" placeholder="correo@ejemplo.com" class="form-input" required>
          </div>
          <button type="submit" class="btn btn-primary btn-full">
            Continuar
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </button>
        </form>
      </div>
    </div>

    <!-- Step 2: Monto -->
    <div v-if="step === 2" class="step-content">
      <div class="form-card">
        <button @click="goBack" class="back-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
          Volver
        </button>
        <h2>Ingresa el monto</h2>
        <div class="recipient-preview">
          <div class="recipient-avatar small">{{ (selectedRecipient?.avatar) || (recipientName || recipientEmail).split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2) }}</div>
          <div><span class="preview-name">{{ selectedRecipient?.name || recipientName || recipientEmail }}</span><span class="preview-email">{{ selectedRecipient?.email || recipientEmail }}</span></div>
        </div>
        <div v-if="errorMsg" class="alert-error">{{ errorMsg }}</div>
        <form @submit.prevent="proceedToConfirm">
          <div class="amount-input-group">
            <span class="currency-symbol">$</span>
            <input v-model="amount" type="number" min="1" placeholder="0" class="amount-input" required>
          </div>
          <div class="form-group">
            <label>Descripción (opcional)</label>
            <input v-model="description" type="text" placeholder="Ej: Pago de lunch" class="form-input">
          </div>
          <div class="quick-amounts">
            <button type="button" @click="amount = 10000"  :class="{ active: amount == 10000  }">$10K</button>
            <button type="button" @click="amount = 25000"  :class="{ active: amount == 25000  }">$25K</button>
            <button type="button" @click="amount = 50000"  :class="{ active: amount == 50000  }">$50K</button>
            <button type="button" @click="amount = 100000" :class="{ active: amount == 100000 }">$100K</button>
          </div>
          <button type="submit" class="btn btn-primary btn-full" :disabled="!amount">
            Continuar
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </button>
        </form>
      </div>
    </div>

    <!-- Step 3: Confirmar -->
    <div v-if="step === 3" class="step-content">
      <div class="form-card">
        <button @click="goBack" class="back-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
          Volver
        </button>
        <h2>Confirma tu transferencia</h2>
        <div v-if="errorMsg" class="alert-error">{{ errorMsg }}</div>
        <div class="transfer-summary">
          <div class="summary-row">
            <span>Para</span>
            <div class="recipient-display">
              <div class="recipient-avatar small">{{ confirmData?.recipient?.avatar }}</div>
              <div class="recipient-details">
                <span class="recipient-name">{{ confirmData?.recipient?.name }}</span>
                <span class="recipient-email">{{ confirmData?.recipient?.email }}</span>
              </div>
            </div>
          </div>
          <div class="summary-divider"></div>
          <div class="summary-row"><span>Monto</span><span class="amount-display">{{ formatCurrency(confirmData?.amount) }}</span></div>
          <div class="summary-row"><span>Saldo después</span><span class="after-balance">{{ formatCurrency(walletStore.balance - (confirmData?.amount || 0)) }}</span></div>
          <div v-if="confirmData?.description" class="summary-row"><span>Descripción</span><span>{{ confirmData.description }}</span></div>
        </div>
        <div class="security-notice">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          <span>Esta transferencia no se puede deshacer. Verifica los datos antes de confirmar.</span>
        </div>
        <button @click="handleSubmit" class="btn btn-success btn-full" :disabled="isSubmitting">
          <span v-if="isSubmitting">Procesando...</span>
          <span v-else>Confirmar Transferencia</span>
          <svg v-if="!isSubmitting" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.transfer-content { max-width: 600px; }
.page-header { margin-bottom: 1.5rem; }
.page-header h1 { font-size: 1.75rem; font-weight: 700; color: #1e3a5f; }
.page-header p  { color: #64748b; font-size: .95rem; }
.alert-success { display:flex;align-items:center;gap:.75rem;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);color:#065f46;padding:.875rem 1.25rem;border-radius:12px;margin-bottom:1.25rem;font-weight:500; }
.alert-success svg { width:20px;height:20px;color:#10b981;flex-shrink:0; }
.alert-error { background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#b91c1c;padding:.75rem 1rem;border-radius:10px;font-size:.875rem;margin-bottom:1rem; }
.balance-bar { display:flex;justify-content:space-between;align-items:center;background:white;border-radius:12px;padding:.875rem 1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.1);margin-bottom:1.5rem;font-size:.9rem;color:#64748b; }
.balance-bar strong { font-size:1.1rem;font-weight:700;color:#1e3a5f; }
.progress-steps { display:flex;align-items:center;justify-content:center;margin-bottom:2rem; }
.step { display:flex;flex-direction:column;align-items:center;gap:.5rem; }
.step-number { width:40px;height:40px;border-radius:50%;background:#e5e7eb;color:#64748b;display:flex;align-items:center;justify-content:center;font-weight:600;transition:all .3s; }
.step.active .step-number { background:#3b82f6;color:white; }
.step.completed .step-number { background:#10b981;color:white; }
.step span { font-size:.75rem;color:#64748b;font-weight:500; }
.step.active span { color:#3b82f6; } .step.completed span { color:#10b981; }
.step-line { width:60px;height:2px;background:#e5e7eb;margin:0 .5rem .5rem;transition:background .3s; }
.step-line.active { background:#3b82f6; }
.form-card { background:white;border-radius:16px;padding:2rem;box-shadow:0 1px 3px rgba(0,0,0,.1); }
.form-card h2 { font-size:1.25rem;font-weight:600;color:#1e3a5f;margin-bottom:.5rem;text-align:center; }
.form-subtitle { color:#64748b;font-size:.875rem;text-align:center;margin-bottom:1.5rem; }
.back-btn { display:flex;align-items:center;gap:.5rem;background:transparent;border:none;color:#64748b;font-size:.875rem;cursor:pointer;margin-bottom:1rem; }
.back-btn svg { width:18px;height:18px; }
.section-label { font-size:.75rem;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;margin-bottom:.75rem; }
.recent-recipients { display:flex;flex-direction:column;gap:.75rem;margin-bottom:1.5rem; }
.recipient-card { display:flex;align-items:center;gap:1rem;padding:1rem;background:#f8fafc;border-radius:12px;cursor:pointer;transition:all .2s;border:2px solid transparent; }
.recipient-card:hover { background:#f1f5f9;border-color:#3b82f6; }
.recipient-arrow { width:16px;height:16px;color:#94a3b8;margin-left:auto;flex-shrink:0; }
.empty-recents { display:flex;flex-direction:column;align-items:center;gap:.75rem;padding:1.5rem;background:#f8fafc;border-radius:12px;margin-bottom:1.5rem;color:#94a3b8;text-align:center;font-size:.85rem; }
.empty-recents svg { width:32px;height:32px; }
.recipient-avatar { width:48px;height:48px;background:linear-gradient(135deg,#3b82f6 0%,#1d4ed8 100%);border-radius:12px;display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:1rem;flex-shrink:0; }
.recipient-avatar.small { width:40px;height:40px;font-size:.875rem;border-radius:10px; }
.recipient-info { display:flex;flex-direction:column; }
.recipient-name { font-weight:600;color:#1e3a5f; }
.recipient-email { font-size:.75rem;color:#64748b; }
.divider { display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem; }
.divider::before,.divider::after { content:'';flex:1;height:1px;background:#e5e7eb; }
.divider span { font-size:.75rem;color:#64748b;white-space:nowrap; }
.form-group { margin-bottom:1.25rem; }
.form-group label { display:block;font-size:.875rem;font-weight:500;color:#374151;margin-bottom:.5rem; }
.required { color:#ef4444; }
.form-input { width:100%;padding:.875rem;border:1px solid #e5e7eb;border-radius:10px;font-size:1rem;transition:border-color .2s;box-sizing:border-box; }
.form-input:focus { outline:none;border-color:#3b82f6; }
.recipient-preview { display:flex;align-items:center;gap:.75rem;padding:.875rem 1rem;background:rgba(59,130,246,.08);border-radius:10px;margin-bottom:1.5rem;border:1px solid rgba(59,130,246,.2); }
.preview-name { display:block;font-weight:600;color:#1e3a5f;font-size:.9rem; }
.preview-email { display:block;font-size:.75rem;color:#64748b; }
.amount-input-group { display:flex;align-items:center;background:#f8fafc;border-radius:12px;padding:.5rem 1rem;margin-bottom:1.5rem;border:2px solid #3b82f6; }
.currency-symbol { font-size:2rem;font-weight:600;color:#64748b;margin-right:.5rem; }
.amount-input { flex:1;border:none;background:transparent;font-size:2rem;font-weight:700;color:#1e3a5f;text-align:right; }
.amount-input:focus { outline:none; }
.quick-amounts { display:grid;grid-template-columns:repeat(4,1fr);gap:.5rem;margin-bottom:1.5rem; }
.quick-amounts button { padding:.75rem;border:1px solid #e5e7eb;background:white;border-radius:8px;font-weight:600;color:#64748b;cursor:pointer;transition:all .2s; }
.quick-amounts button:hover,.quick-amounts button.active { background:#3b82f6;color:white;border-color:#3b82f6; }
.btn { display:flex;align-items:center;justify-content:center;gap:.5rem;padding:1rem;border-radius:12px;font-size:1rem;font-weight:600;border:none;cursor:pointer;transition:all .2s; }
.btn svg { width:20px;height:20px; }
.btn-full { width:100%; }
.btn-primary { background:#3b82f6;color:white; }
.btn-primary:hover:not(:disabled) { background:#2563eb; }
.btn-primary:disabled { opacity:.5;cursor:not-allowed; }
.btn-success { background:#10b981;color:white; }
.btn-success:hover:not(:disabled) { background:#059669; }
.btn-success:disabled { opacity:.5;cursor:not-allowed; }
.transfer-summary { background:#f8fafc;border-radius:12px;padding:1.5rem;margin-bottom:1.5rem; }
.summary-row { display:flex;justify-content:space-between;align-items:center;padding:.75rem 0; }
.summary-row span:first-child { color:#64748b;font-size:.875rem; }
.summary-divider { height:1px;background:#e5e7eb;margin:.5rem 0; }
.amount-display { font-size:1.5rem;font-weight:700;color:#1e3a5f; }
.after-balance  { font-size:1rem;font-weight:600;color:#10b981; }
.recipient-display { display:flex;align-items:center;gap:.75rem; }
.recipient-details { display:flex;flex-direction:column; }
.security-notice { display:flex;align-items:flex-start;gap:.75rem;padding:1rem;background:rgba(234,179,8,.1);border-radius:10px;margin-bottom:1.5rem; }
.security-notice svg { width:20px;height:20px;color:#ca8a04;flex-shrink:0;margin-top:.125rem; }
.security-notice span { font-size:.8rem;color:#92400e;line-height:1.4; }
</style>
