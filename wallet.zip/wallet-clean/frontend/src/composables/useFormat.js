export function useFormat() {
  const formatCurrency = (v) =>
    new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0
    }).format(v || 0)

  const formatDate = (val) => {
    const d = val?.created_at ?? val
    if (!d) return ''
    const date = typeof d === 'string' ? new Date(d) : d
    if (isNaN(date)) return ''
    return date.toLocaleDateString('es-CO', { day: 'numeric', month: 'short', year: 'numeric' })
  }

  const formatDateTime = (val) => {
    if (!val) return ''
    const d = new Date(val)
    return (
      d.toLocaleDateString('es-CO', { day: 'numeric', month: 'short' }) +
      ' · ' +
      d.toTimeString().slice(0, 5)
    )
  }

  return { formatCurrency, formatDate, formatDateTime }
}
